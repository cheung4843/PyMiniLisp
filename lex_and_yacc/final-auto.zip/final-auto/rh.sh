#!/bin/bash
echo "final proj test";
echo "----- 01_1_hidden.lsp -----";
./pf < ./testdata/01_1_hidden.lsp
echo

echo "----- 01_2_hidden.lsp -----";
./pf < ./testdata/01_2_hidden.lsp
echo

echo "----- 02_1_hidden.lsp -----";
./pf < ./testdata/02_1_hidden.lsp
echo

echo "----- 02_2_hidden.lsp -----";
./pf < ./testdata/02_2_hidden.lsp
echo

echo "----- 03_1_hidden.lsp -----";
./pf < ./testdata/03_1_hidden.lsp
echo

echo "----- 03_2_hidden.lsp -----";
./pf < ./testdata/03_2_hidden.lsp
echo

echo "----- 04_1_hidden.lsp -----";
./pf < ./testdata/04_1_hidden.lsp
echo

echo "----- 04_2_hidden.lsp -----";
./pf < ./testdata/04_2_hidden.lsp
echo

echo "----- 05_1_hidden.lsp -----";
./pf < ./testdata/05_1_hidden.lsp
echo

echo "----- 05_2_hidden.lsp -----";
./pf < ./testdata/05_2_hidden.lsp
echo

echo "----- 06_1_hidden.lsp -----";
./pf < ./testdata/06_1_hidden.lsp
echo

echo "----- 06_2_hidden.lsp -----";
./pf < ./testdata/06_2_hidden.lsp
echo

echo "----- 07_1_hidden.lsp -----";
./pf < ./testdata/07_1_hidden.lsp
echo

echo "----- 07_2_hidden.lsp -----";
./pf < ./testdata/07_2_hidden.lsp
echo

echo "----- 08_1_hidden.lsp -----";
./pf < ./testdata/08_1_hidden.lsp
echo

echo "----- 08_2_hidden.lsp -----";
./pf < ./testdata/08_2_hidden.lsp
echo

echo "----- b1_1_hidden.lsp -----";
./pf < ./testdata/b1_1_hidden.lsp
echo

echo "----- b1_2_hidden.lsp -----";
./pf < ./testdata/b1_2_hidden.lsp
echo

echo "----- b2_1_hidden.lsp -----";
./pf < ./testdata/b2_1_hidden.lsp
echo

echo "----- b2_2_hidden.lsp -----";
./pf < ./testdata/b2_2_hidden.lsp
echo

echo "----- b3_1_hidden.lsp -----";
./pf < ./testdata/b3_1_hidden.lsp
echo

echo "----- b3_2_hidden.lsp -----";
./pf < ./testdata/b3_2_hidden.lsp
echo

echo "----- b4_1_hidden.lsp -----";
./pf < ./testdata/b4_1_hidden.lsp
echo

echo "----- b4_2_hidden.lsp -----";
./pf < ./testdata/b4_2_hidden.lsp
echo
