#!/bin/bash
echo "final proj test";
echo "----- 01_1.lsp -----";
./pf < ./testdata/01_1.lsp
echo

echo "----- 01_2.lsp -----";
./pf < ./testdata/01_2.lsp
echo

echo "----- 02_1.lsp -----";
./pf < ./testdata/02_1.lsp
echo

echo "----- 02_2.lsp -----";
./pf < ./testdata/02_2.lsp
echo

echo "----- 03_1.lsp -----";
./pf < ./testdata/03_1.lsp
echo

echo "----- 03_2.lsp -----";
./pf < ./testdata/03_2.lsp
echo

echo "----- 04_1.lsp -----";
./pf < ./testdata/04_1.lsp
echo

echo "----- 04_2.lsp -----";
./pf < ./testdata/04_2.lsp
echo

echo "----- 05_1.lsp -----";
./pf < ./testdata/05_1.lsp
echo

echo "----- 05_2.lsp -----";
./pf < ./testdata/05_2.lsp
echo

echo "----- 06_1.lsp -----";
./pf < ./testdata/06_1.lsp
echo

echo "----- 06_2.lsp -----";
./pf < ./testdata/06_2.lsp
echo

echo "----- 07_1.lsp -----";
./pf < ./testdata/07_1.lsp
echo

echo "----- 07_2.lsp -----";
./pf < ./testdata/07_2.lsp
echo

echo "----- 08_1.lsp -----";
./pf < ./testdata/08_1.lsp
echo

echo "----- 08_2.lsp -----";
./pf < ./testdata/08_2.lsp
echo

echo "----- b1_1.lsp -----";
./pf < ./testdata/b1_1.lsp
echo

echo "----- b1_2.lsp -----";
./pf < ./testdata/b1_2.lsp
echo

echo "----- b2_1.lsp -----";
./pf < ./testdata/b2_1.lsp
echo

echo "----- b2_2.lsp -----";
./pf < ./testdata/b2_2.lsp
echo

echo "----- b3_1.lsp -----";
./pf < ./testdata/b3_1.lsp
echo

echo "----- b3_2.lsp -----";
./pf < ./testdata/b3_2.lsp
echo

echo "----- b4_1.lsp -----";
./pf < ./testdata/b4_1.lsp
echo

echo "----- b4_2.lsp -----";
./pf < ./testdata/b4_2.lsp
echo
